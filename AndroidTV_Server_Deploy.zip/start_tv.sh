#!/data/data/com.termux/files/usr/bin/bash
# =================================================================
#  Prayer Times TV Screen - Android TV (Termux) Startup Script
#  By Mr. Ahmed RASNAAMA
# =================================================================

# Change directory to the script's location
cd "$(dirname "$0")"

echo "==================================================="
echo "Starting Prayer Times Calculator Server in Termux..."
echo "==================================================="

# Ensure the executable has execute permissions
if [ -f "./prayer-times-calculator" ]; then
    chmod +x ./prayer-times-calculator
else
    echo "WARNING: './prayer-times-calculator' executable not found."
    echo "Please copy the precompiled aarch64-linux-android binary to this folder."
fi

# Run the server in the background, redirecting output to server.log
./prayer-times-calculator serve --port 8080 > server.log 2>&1 &
SERVER_PID=$!

echo "Server started with PID: $SERVER_PID. Logging to 'server.log'..."
echo "Waiting 2 seconds for server to initialize..."
sleep 2

# Check if server is running
if ! kill -0 $SERVER_PID 2>/dev/null; then
    echo "ERROR: Server failed to start! Check 'server.log' for details."
    exit 1
fi

# Get the IP address of the Android TV on the local network
IP_ADDR=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7}' || ip route get 8.8.8.8 2>/dev/null | awk '{print $7}')
if [ -empty "$IP_ADDR" ]; then
    IP_ADDR="<YOUR_TV_IP_ADDRESS>"
fi

echo "==================================================="
echo "Server is running successfully!"
echo "--------------------------------------------------"
echo "To view the TV Screen on this Android TV:"
echo "1. Open a TV web browser (like 'TV Bro' or 'JioPages')."
echo "2. Go to: http://localhost:8080/tv"
echo ""
echo "To view from other devices on the same Wi-Fi:"
echo "- Go to: http://$IP_ADDR:8080/tv"
echo "==================================================="
echo "Press Ctrl+C in this Termux window to stop the server."
echo "==================================================="

# Wait for background processes to keep Termux active
wait $SERVER_PID
