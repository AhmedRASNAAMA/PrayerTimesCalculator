# 🕌 Android TV Deployment Guide | دليل تشغيل أجهزة التلفاز أندرويد

Android TV runs the Android OS. To display your prayer times on an Android TV, you can choose one of the following two deployment methods:

تعمل أجهزة التلفاز الذكية بنظام تشغيل أندرويد (Android TV). لعرض مواقيت الصلاة على التلفاز، يمكنك اختيار أحد الحلين التاليين:

---

## Method 1: Networked TV Viewer (Recommended) / الطريقة الأولى: العرض عبر الشبكة المحلية (موصى بها)

In this setup, the server (`prayer-times-calculator`) runs on a computer or Raspberry Pi on the local network. The Android TV acts as a display client.

في هذا النظام، يتم تشغيل الخادم (`prayer-times-calculator`) على جهاز كمبيوتر أو راسبري باي متصل بالشبكة المحلية، بينما يعمل التلفاز كشاشة عرض فقط.

### Step A: Start the Server / أولاً: تشغيل الخادم
Ensure the server is running on a local PC (Windows/Linux) or Raspberry Pi on the same Wi-Fi network. Note down its IP address (e.g., `http://192.168.1.100:8080`).

تأكد من تشغيل الخادم على جهاز كمبيوتر أو راسبري باي متصل بنفس شبكة الواي فاي. قم بمعرفة عنوان الـ IP للجهاز (مثال: `http://192.168.1.100:8080`).

### Step B: Choose a display method / ثانياً: طريقة العرض على التلفاز

#### Option 1: Use the Native WebView TV App (Included in this folder) / الخيار أ: استخدام تطبيق التلفاز المخصص (مرفق في هذا المجلد)
We have included a complete Android Studio project template (`PrayerTimesTVApp`) that compiles into a native TV `.apk`.

لقد أرفقنا مشروعاً برمجياً متكاملاً (`PrayerTimesTVApp`) يمكنك فتحه في برنامج **Android Studio** وتجميعه إلى تطبيق تلفاز أصلي تثبته مباشرة:

1. Install **Android Studio** on your computer.
   * *قم بتثبيت برنامج Android Studio على جهاز الكمبيوتر الخاص بك.*
2. Open the project folder `deploy/android_tv/PrayerTimesTVApp` in Android Studio.
   * *افتح مجلد المشروع `deploy/android_tv/PrayerTimesTVApp` داخل البرنامج.*
3. Open `MainActivity.kt` at:
   `app/src/main/java/com/prayertimes/tv/MainActivity.kt`
   * *افتح ملف `MainActivity.kt` البرمجي.*
4. Edit the `serverUrl` variable (around line 22) and set it to your server's local IP address:
   * *قم بتعديل متغير عنوان الخادم (سطر 22) ووضعه ليتطابق مع الـ IP الخاص بجهازك:*
   ```kotlin
   private var serverUrl = "http://192.168.1.100:8080/tv"
   ```
5. Build the APK: Go to `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   * *قم بتجميع التطبيق: اضغط على Build في القائمة العلوية ثم Build APK(s).*
6. Transfer the generated APK file (found in `app/build/outputs/apk/debug/app-debug.apk`) to your Android TV (via a USB drive, Google Drive, or ADB) and install it (sideloading).
   * *انقل ملف الـ APK الناتج إلى جهاز التلفاز وثبته (قد تحتاج لتفعيل تثبيت التطبيقات من مصادر غير معروفة).*

#### Option 2: Use an Android TV Web Browser / الخيار ب: استخدام متصفح ويب مخصص للتلفاز
If you do not wish to compile the native app, you can simply install a TV web browser:

إذا كنت لا ترغب في تجميع التطبيق بنفسك، يمكنك استخدام أي متصفح ويب متاح على متجر التلفاز:

1. Open the Google Play Store on your Android TV.
   * *افتح متجر جوجل بلاي على التلفاز.*
2. Search for and install **TV Bro** or **Odin Browser** or **JioPages**. (We recommend **TV Bro** because it supports scrolling disable, keeps the screen awake, and can start on boot).
   * *ابحث عن متصفح **TV Bro** وقم بتثبيته (موصى به لدعمه الشاشة الكاملة ومنع انطفاء الشاشة).*
3. Open the browser and enter the server URL: `http://<YOUR-SERVER-IP>:8080/tv`
   * *افتح المتصفح واكتب عنوان خادمك: `http://<YOUR-SERVER-IP>:8080/tv`.*

---

## Method 2: Standalone Local Server on TV (Advanced) / الطريقة الثانية: تشغيل الخادم مباشرة على التلفاز (للمحترفين)

You can run the Rust binary directly on your Android TV using **Termux**. We provide a precompiled binary for Android ARM64 architecture so you don't need to compile it on the TV itself.

يمكنك تشغيل الخادم البرمجي مباشرة على جهاز التلفاز نفسه دون الحاجة لجهاز آخر باستخدام بيئة **Termux**. لقد قمنا بتجميع البرنامج مسبقاً لمعمارية أندرويد ليوفر عليك عناء ووقت التجميع على التلفاز.

### Option A: Use the Precompiled Binary (Recommended) / الخيار أ: استخدام الملف المجمع مسبقاً (مستحسن)

1. Sideload the **Termux** APK onto your Android TV.
   * *قم بتثبيت تطبيق Termux (APK) على جهاز التلفاز.*
2. Copy the contents of the `deploy/android_tv/server/` folder to your TV (via a USB drive, SFTP, or an app like 'Send Files to TV').
   * *انسخ محتويات مجلد `deploy/android_tv/server/` إلى التلفاز.*
3. Open Termux and navigate to the copied folder:
   * *افتح تطبيق Termux وانتقل لمجلد البرنامج:*
   ```bash
   cd /path/to/copied/server/
   ```
4. Set execution permissions for the script and the binary:
   * *امنح صلاحيات التشغيل للملفات:*
   ```bash
   chmod +x start_tv.sh prayer-times-calculator
   ```
5. Start the server using the startup script:
   * *قم بتشغيل البرنامج باستخدام ملف التشغيل السريع:*
   ```bash
   ./start_tv.sh
   ```
6. Open your TV web browser and navigate to `http://localhost:8080/tv`.
   * *افتح متصفح التلفاز وادخل إلى الرابط المحلي `http://localhost:8080/tv`.*

---

### Option B: Build Directly on the TV (Fallback) / الخيار ب: التجميع مباشرة على جهاز التلفاز

If the precompiled binary does not run on your device, you can compile it directly in Termux:

إذا لم يعمل الملف المجمع مسبقاً على جهازك، يمكنك تجميعه بنفسك داخل تطبيق Termux:

1. Open Termux and install Rust, clang, and make:
   * *افتح تطبيق Termux وثبت بيئة Rust:*
   ```bash
   pkg update
   pkg install rust clang make -y
   ```
2. Copy the entire source code of the project to your TV.
   * *انسخ ملفات المشروع بالكامل إلى داخل بيئة Termux على التلفاز.*
3. Navigate to the project folder and compile:
   * *قم بتجميع المشروع:*
   ```bash
   cargo build --release
   ```
4. Copy the compiled binary from `target/release/prayer-times-calculator` into your server deploy directory:
   * *انقل الملف التنفيذي الناتج إلى مجلد التشغيل:*
   ```bash
   cp target/release/prayer-times-calculator deploy/android_tv/server/
   ```
5. Run using the steps from Option A.
   * *قم بالتشغيل باتباع خطوات الخيار أ.*

