# 🕌 Linux PC Deployment Guide | دليل تشغيل أجهزة لينكس

This directory contains the files required to run the **Prayer Times TV Screen & Server** on a Linux PC (Ubuntu, Debian, Fedora, Linux Mint, etc.).

يحتوي هذا المجلد على الملفات اللازمة لتشغيل **شاشة مواقيت الصلاة والخادم** على الأجهزة التي تعمل بنظام لينكس (Linux).

---

## 📋 Contents / المحتويات

1. `start_tv.sh` - Bash startup script to run the server in the background and open Google Chrome, Chromium, or Firefox in fullscreen kiosk mode.
   * *ملف تشغيل سريع يقوم بتشغيل الخادم تلقائياً وفتح المتصفح في وضع الشاشة الكاملة.*
2. `tv_config.json` - Configuration file storing settings, locations, and calculation methods.
   * *ملف إعدادات الموقع والمواقيت والمظهر لشاشة التلفاز.*

---

## 🛠️ Compilation / التجميع والتركيب

Since you are developing on a Windows host, you must compile the application for the Linux x86_64 architecture.

بما أنك تقوم بالتطوير على نظام تشغيل ويندوز، يجب عليك تجميع البرنامج ليتوافق مع نظام تشغيل لينكس بمعمارية x86_64.

### Option A: Build Directly on the Linux Machine (Easiest) / الخيار أ: التجميع مباشرة على جهاز لينكس

1. Copy the source code folder to your Linux machine.
   * *انسخ مجلد المشروع بالكامل إلى جهاز لينكس الخاص بك.*
2. Install Rust/Cargo if you haven't already:
   * *قم بتثبيت لغة Rust إن لم تكن مثبتة:*
   ```bash
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   source $HOME/.cargo/env
   ```
3. Run the compilation inside the project directory:
   * *قم بتجميع المشروع في وضع الإصدار النهائي (Release Mode):*
   ```bash
   cargo build --release
   ```
4. Copy the compiled executable from `target/release/prayer-times-calculator` into this `deploy/linux/` folder.
   * *انقل الملف التنفيذي الناتج من المسار `target/release/prayer-times-calculator` إلى هذا المجلد.*

---

### Option B: Cross-Compile from Windows (Fastest) / الخيار ب: التجميع العابر من نظام ويندوز

You can cross-compile from Windows using **Cargo Cross**.

يمكنك تجميع البرنامج من ويندوز مستخدماً أداة **Cross** لتجميع الشيفرة البرمجية لمعمارية لينكس x86_64:

1. Install Docker Desktop on Windows.
   * *قم بتثبيت برنامج Docker Desktop على نظام ويندوز.*
2. Install Cross via PowerShell/CMD:
   * *ثبت أداة Cross عبر سطر الأوامر:*
   ```powershell
   cargo install cross --git https://github.com/cross-rs/cross
   ```
3. Compile for 64-bit Linux:
   * *قم بالتجميع لمعمارية Linux x86_64:*
   ```powershell
   cross build --target x86_64-unknown-linux-gnu --release
   ```
4. Copy the binary from `target/x86_64-unknown-linux-gnu/release/prayer-times-calculator` into this `deploy/linux/` folder.
   * *انسخ الملف التنفيذي الناتج إلى هذا المجلد.*

---

## 🚀 Running / التشغيل والتنفيذ

Once the `prayer-times-calculator` binary is in this folder:

بمجرد وضع الملف التنفيذي `prayer-times-calculator` داخل هذا المجلد:

1. Grant execute permissions to the script and binary:
   * *امنح صلاحيات التنفيذ للملفات:*
   ```bash
   chmod +x start_tv.sh prayer-times-calculator
   ```
2. Start the system:
   * *قم بتشغيل النظام:*
   ```bash
   ./start_tv.sh
   ```

---

## 📺 Auto-Start on Boot / التشغيل التلقائي عند الإقلاع

To configure Linux to launch the TV Screen automatically when it boots:

لإعداد نظام لينكس ليقوم بفتح شاشة مواقيت الصلاة تلقائياً عند التشغيل:

### Method 1: Using Autostart Applications (GUI) / الطريقة الأولى: استخدام تطبيقات بدء التشغيل تلقائياً

Most Linux distributions (Ubuntu/Gnome, Mint/Cinnamon) have a GUI program called "Startup Applications" or "Autostart".

تحتوي معظم توزيعات لينكس (مثل أوبونتو أو لينكس مينت) على برنامج رسومي يسمى "تطبيقات بدء التشغيل" (Startup Applications):

1. Open **Startup Applications** from your app launcher.
   * *افتح برنامج "Startup Applications" من قائمة التطبيقات.*
2. Click **Add / إضافة**.
   * *اضغط على زر إضافة.*
3. Fill in the fields:
   * **Name**: `Prayer Times TV`
   * **Command**: Click Browse and select the `start_tv.sh` script in this directory, or enter:
     `/absolute/path/to/deploy/linux/start_tv.sh`
4. Click **Save**.
   * *اضغط على حفظ وأعد تشغيل الجهاز.*

---

## ⚙️ Administration & Configuration / الإدارة والضبط

* **Admin Panel / لوحة التحكم**: Access `http://localhost:8080/` from any web browser to adjust settings, city, offsets, and themes.
  * *يمكنك الدخول إلى لوحة التحكم من المتصفح عبر العنوان `http://localhost:8080/` لتعديل إعدادات الموقع، الفوارق الزمنية، أو الثيمات.*
* **TV Display / شاشة العرض**: The screen is accessible at `http://localhost:8080/tv`.
  * *يمكنك عرض الشاشة مباشرة عبر المتصفح عن طريق `http://localhost:8080/tv`.*
