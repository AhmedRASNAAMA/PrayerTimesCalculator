#!/bin/bash
# =================================================================
#  Prayer Times TV Screen - Linux Startup Script
#  By Mr. Ahmed RASNAAMA
# =================================================================

# Change directory to the script's location
cd "$(dirname "$0")"

echo "==================================================="
# Arabic: بدء تشغيل خادم مواقيت الصلاة...
echo "Starting Prayer Times Calculator Server..."
echo "==================================================="

# Ensure the executable has execute permissions
if [ -f "./prayer-times-calculator" ]; then
    chmod +x ./prayer-times-calculator
else
    # Arabic: تحذير: ملف تشغيل البرنامج غير موجود!
    echo "WARNING: './prayer-times-calculator' executable not found."
    echo "Please compile it or place the binary in this folder."
fi

# Run the server in the background, redirecting output to server.log
./prayer-times-calculator serve --port 8080 > server.log 2>&1 &
SERVER_PID=$!

echo "Server started with PID: $SERVER_PID. Logging to 'server.log'..."
echo "Waiting 2 seconds for server to initialize..."
sleep 2

# Check if server is running
if ! kill -0 $SERVER_PID 2>/dev/null; then
    # Arabic: خطأ: فشل تشغيل الخادم!
    echo "ERROR: Server failed to start! Check 'server.log' for details."
    exit 1
fi

echo "Opening TV screen in fullscreen Kiosk mode..."

# Disable screensaver and power management (common X11 commands)
if command -v xset &> /dev/null; then
    xset s off 2>/dev/null
    xset -dpms 2>/dev/null
    xset s noblank 2>/dev/null
fi

# Try to launch Chrome, Chromium, or Firefox in kiosk/fullscreen mode
if command -v google-chrome &> /dev/null; then
    google-chrome --kiosk --noerrdialogs --disable-infobars --no-first-run http://localhost:8080/tv &
elif command -v chromium-browser &> /dev/null; then
    chromium-browser --kiosk --noerrdialogs --disable-infobars --no-first-run http://localhost:8080/tv &
elif command -v chromium &> /dev/null; then
    chromium --kiosk --noerrdialogs --disable-infobars --no-first-run http://localhost:8080/tv &
elif command -v firefox &> /dev/null; then
    firefox --kiosk http://localhost:8080/tv &
else
    # Fallback to default browser
    # Arabic: لم يتم العثور على متصفح Chrome/Firefox. فتح المتصفح الافتراضي...
    echo "No standard browser found in kiosk mode. Opening in default browser..."
    xdg-open "http://localhost:8080/tv" &
fi

echo "==================================================="
# Arabic: تم تشغيل النظام بنجاح!
echo "Startup complete! Keep this terminal open or run in background."
echo "Press Ctrl+C in this terminal to stop the server (PID: $SERVER_PID)"
echo "==================================================="

# Wait for background processes to keep terminal open if run interactively
wait $SERVER_PID
