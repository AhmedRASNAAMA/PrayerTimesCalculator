# 🕌 Raspberry Pi Deployment Guide | دليل تشغيل راسبري باي

This directory contains the files required to run the **Prayer Times TV Screen & Server** on a Raspberry Pi.

يحتوي هذا المجلد على الملفات اللازمة لتشغيل **شاشة مواقيت الصلاة والخادم** على جهاز راسبري باي (Raspberry Pi).

---

## 📋 Contents / المحتويات

1. `start_tv.sh` - Bash startup script to run the server in the background and open Chromium in fullscreen kiosk mode.
   * *ملف تشغيل سريع يقوم بتشغيل الخادم تلقائياً وفتح متصفح كروميوم في وضع الشاشة الكاملة.*
2. `tv_config.json` - Configuration file storing settings, locations, and calculation methods.
   * *ملف إعدادات الموقع والمواقيت والمظهر لشاشة التلفاز.*

---

## 🛠️ Compilation & Setup / التجميع والتركيب

Since you are developing on a Windows host, you must compile the application for the Raspberry Pi's CPU architecture (usually **ARMv7 32-bit** or **AArch64 64-bit** Linux).

بما أنك تقوم بالتطوير على نظام تشغيل ويندوز، يجب عليك تجميع البرنامج ليتوافق مع معمارية معالج جهاز راسبري باي (غالباً ما تكون معمارية **AArch64 64-bit** أو **ARMv7 32-bit** لينكس).

### Option A: Build Directly on the Raspberry Pi (Easiest) / الخيار أ: التجميع مباشرة على جهاز راسبري باي

1. Copy the source code folder to your Raspberry Pi (via USB, SCP, or Git).
   * *انسخ مجلد المشروع بالكامل إلى جهاز راسبري باي.*
2. Open the terminal on your Pi and install Rust/Cargo (if not installed):
   * *افتح وحدة التحكم (Terminal) على الجهاز وقم بتثبيت لغة Rust:*
   ```bash
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   source $HOME/.cargo/env
   ```
3. Run the compilation inside the project directory:
   * *قم بتجميع المشروع في وضع الإصدار النهائي (Release Mode):*
   ```bash
   cargo build --release
   ```
4. Copy the compiled executable from `target/release/prayer-times-calculator` into this `deploy/raspberry_pi/` folder.
   * *انقل الملف التنفيذي الناتج من المسار `target/release/prayer-times-calculator` إلى هذا المجلد.*

---

### Option B: Cross-Compile from Windows (Fastest) / الخيار ب: التجميع العابر من نظام ويندوز

You can cross-compile from Windows using **Cargo Cross**.

يمكنك تجميع البرنامج من ويندوز مستخدماً أداة **Cross** لتجميع الشيفرة البرمجية لمعمارية لينكس:

1. Install Docker Desktop on Windows.
   * *قم بتثبيت برنامج Docker Desktop على نظام ويندوز.*
2. Install Cross via PowerShell/CMD:
   * *ثبت أداة Cross عبر سطر الأوامر:*
   ```powershell
   cargo install cross --git https://github.com/cross-rs/cross
   ```
3. Compile for 64-bit Raspberry Pi OS (Pi 3/4/5/Zero 2):
   * *قم بالتجميع لمعمارية AArch64 (نظام 64 بت لراسبري باي 3/4/5):*
   ```powershell
   cross build --target aarch64-unknown-linux-gnu --release
   ```
4. Or compile for 32-bit Raspberry Pi OS:
   * *أو قم بالتجميع لنظام 32 بت:*
   ```powershell
   cross build --target armv7-unknown-linux-gnueabihf --release
   ```
5. Copy the binary from `target/<target-name>/release/prayer-times-calculator` into this `deploy/raspberry_pi/` folder.
   * *انسخ الملف التنفيذي الناتج إلى هذا المجلد.*

---

## 🚀 Running / التشغيل والتنفيذ

Once the `prayer-times-calculator` binary is in this folder:

بمجرد وضع الملف التنفيذي `prayer-times-calculator` داخل هذا المجلد:

1. Grant execute permissions to the script and binary:
   * *امنح صلاحيات التنفيذ للملفات:*
   ```bash
   chmod +x start_tv.sh prayer-times-calculator
   ```
2. Start the system:
   * *قم بتشغيل النظام:*
   ```bash
   ./start_tv.sh
   ```

---

## 📺 Auto-Start on Boot / التشغيل التلقائي عند الإقلاع

To configure the Raspberry Pi to launch the TV Screen automatically when it boots:

لإعداد جهاز راسبري باي ليقوم بفتح شاشة مواقيت الصلاة تلقائياً عند التشغيل:

### Method 1: LXDE Autostart (Desktop Environment) / الطريقة الأولى: إعدادات واجهة المستخدم الرسومية

1. Create a local autostart directory if it does not exist:
   * *أنشئ مجلد التشغيل التلقائي إن لم يكن موجوداً:*
   ```bash
   mkdir -p ~/.config/autostart
   ```
2. Create an autostart desktop entry:
   * *أنشئ ملف إعدادات تشغيل تلقائي جديد:*
   ```bash
   nano ~/.config/autostart/prayertimes.desktop
   ```
3. Paste the following configuration (replace `/path/to/deploy/raspberry_pi/` with the absolute path of this folder on your Pi):
   * *ألصق الإعدادات التالية (مع استبدال المسار بالمسار الحقيقي لهذا المجلد على جهازك):*
   ```ini
   [Desktop Entry]
   Type=Application
   Name=Prayer Times TV
   Exec=/path/to/deploy/raspberry_pi/start_tv.sh
   StartupNotify=false
   Terminal=true
   ```
4. Save and close (Ctrl+O, Enter, Ctrl+X). Reboot your Pi to verify.
   * *احفظ الملف وأعد تشغيل الجهاز للتحقق من عمله.*

---

## ⚙️ Administration & Configuration / الإدارة والضبط

* **Admin Panel / لوحة التحكم**: Access `http://localhost:8080/` from any web browser to adjust settings, city, offsets, and themes.
  * *يمكنك الدخول إلى لوحة التحكم من المتصفح عبر العنوان `http://localhost:8080/` لتعديل إعدادات الموقع، الفوارق الزمنية، أو الثيمات.*
* **TV Display / شاشة العرض**: The screen is accessible at `http://localhost:8080/tv`.
  * *يمكنك عرض الشاشة مباشرة عبر المتصفح عن طريق `http://localhost:8080/tv`.*
