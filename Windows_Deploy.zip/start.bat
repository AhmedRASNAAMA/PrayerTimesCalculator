@echo off
title Prayer Times Calculator Server -- By Mr. Ahmed RASNAAMA
echo ===================================================
echo     Starting Prayer Times Calculator Server...
echo ===================================================
echo                By Mr. Ahmed RASNAAMA
echo ===================================================
echo.

cd /d "%~dp0"
start "Prayer Times Server" /MIN prayer-times-calculator.exe serve --port 8080

:: Wait for 2 seconds to make sure the server is fully started
timeout /t 2 /nobreak >nul

echo Opening dashboard...
start "" "http://localhost:8080/"

echo Opening TV screen in fullscreen...

:: 1. Check Chrome
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" >nul 2>nul
set BROWSER_FOUND=%ERRORLEVEL%
if %BROWSER_FOUND% neq 0 (
    reg query "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" >nul 2>nul
    set BROWSER_FOUND=%ERRORLEVEL%
)
if %BROWSER_FOUND% equ 0 (
    start chrome --app="http://localhost:8080/tv" --start-fullscreen
    set NEED_F11=1
    goto browser_done
)

:: 2. Check Edge
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" >nul 2>nul
set BROWSER_FOUND=%ERRORLEVEL%
if %BROWSER_FOUND% neq 0 (
    reg query "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" >nul 2>nul
    set BROWSER_FOUND=%ERRORLEVEL%
)
if %BROWSER_FOUND% equ 0 (
    start msedge --app="http://localhost:8080/tv" --start-fullscreen
    set NEED_F11=1
    goto browser_done
)

:: 3. Check Firefox
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe" >nul 2>nul
set BROWSER_FOUND=%ERRORLEVEL%
if %BROWSER_FOUND% neq 0 (
    reg query "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe" >nul 2>nul
    set BROWSER_FOUND=%ERRORLEVEL%
)
if %BROWSER_FOUND% equ 0 (
    start firefox --new-window --kiosk "http://localhost:8080/tv"
    set NEED_F11=0
    goto browser_done
)

:: Fallback: Open in default browser (no fullscreen support via command line)
start "" "http://localhost:8080/tv"
set NEED_F11=1

:browser_done

:: If F11 is not needed (e.g. Firefox kiosk), jump to the end
if "%NEED_F11%"=="0" goto end_script

echo Sending F11 to activate fullscreen...
echo Set WshShell = WScript.CreateObject("WScript.Shell") > "%temp%\fullscreen.vbs"
echo WScript.Sleep 2000 >> "%temp%\fullscreen.vbs"
echo WshShell.AppActivate "شاشة مواقيت الصلاة" >> "%temp%\fullscreen.vbs"
echo WshShell.SendKeys "{F11}" >> "%temp%\fullscreen.vbs"
cscript //nologo "%temp%\fullscreen.vbs" >nul 2>nul
del "%temp%\fullscreen.vbs" >nul 2>nul

:end_script

echo.
echo ===================================================
echo   Server started and browser windows opened.
echo ===================================================
echo.
