===================================================
   Prayer Times Calculator - دليل التشغيل والاستخدام
===================================================
			By Mr. Ahmed RASNAAMA
===================================================

[العربية]
هذا المجلد يحتوي على النسخة الجاهزة للتشغيل (Deployment) الخاصة ببرنامج حساب مواقيت الصلاة.

محتويات المجلد:
1. `prayer-times-calculator.exe` - البرنامج التنفيذي الرئيسي.
2. `start.bat` - ملف تشغيل سريع يقوم بتشغيل الخادم تلقائياً.
3. `tv_config.json` - ملف يحتوي على الإعدادات الحالية لشاشة التلفاز والمواقيت.

طريقة التشغيل والاستخدام:
1. انقر نقراً مزدوجاً فوق ملف `start.bat` لتشغيل خادم البرنامج.
2. ستفتح نافذة سوداء (ترجمان الأوامر)، يرجى إبقاؤها مفتوحة طوال فترة عمل البرنامج.
3. للوصول إلى الواجهات:
   - لوحة التحكم وإدارة المواقيت: افتح المتصفح واذهب إلى http://localhost:8080/
   - شاشة عرض مواقيت الصلاة (شاشة التلفاز): اذهب إلى http://localhost:8080/tv

ملاحظات هامة:
- يتم حفظ إعدادات شاشة التلفاز والموقع تلقائياً في ملف `tv_config.json` عند تعديلها من لوحة التحكم في شاشة التلفاز.
- يتطلب البرنامج تثبيت حزمة MSVC C++ Redistributable لتفادي مشاكل نقص ملفات الـ DLL على النسخ الجديدة من نظام التشغيل Windows. يمكنك تحميلها من الروابط الرسمية التالية:
  * نسخة 64 بت (X64): https://aka.ms/vc14/vc_redist.x64.exe
  * نسخة 32 بت (X86): https://aka.ms/vc14/vc_redist.x86.exe
- يوصى باستخدام متصفح Google Chrome للحصول على أفضل تجربة لعرض الشاشة الكاملة التلقائي (fullscreen)، على الرغم من دعم متصفحي Microsoft Edge و Firefox أيضاً.
- لإغلاق البرنامج، يمكنك ببساطة إغلاق نافذة `start.bat` السوداء.

---------------------------------------------------

[English]
This folder contains the ready-to-run deployment files for the Prayer Times Calculator.

Folder Contents:
1. `prayer-times-calculator.exe` - The main executable application.
2. `start.bat` - A shortcut file to automatically start the application server.
3. `tv_config.json` - Stores current configuration settings for location, calculations, and the TV display.

How to Run & Use:
1. Double-click the `start.bat` file to start the server.
2. A black terminal window will open. Keep this window open while using the application.
3. Access the interfaces via your web browser:
   - Admin & Calculation Dashboard: http://localhost:8080/
   - TV Screen / Prayer Display: http://localhost:8080/tv

Important Notes:
- The application requires the MSVC C++ Redistributable package installed on fresh Windows systems to prevent missing DLL errors (e.g., `vcruntime140.dll`). You can download it using the official links:
  * X64: https://aka.ms/vc14/vc_redist.x64.exe
  * X86: https://aka.ms/vc14/vc_redist.x86.exe
- Google Chrome is highly recommended for the best automated fullscreen kiosk experience, though Microsoft Edge and Firefox are also supported.
- TV Display and calculator settings are automatically saved in `tv_config.json` when updated through the admin panel on the TV screen interface.
- To stop the server, simply close the black terminal window.
===================================================
